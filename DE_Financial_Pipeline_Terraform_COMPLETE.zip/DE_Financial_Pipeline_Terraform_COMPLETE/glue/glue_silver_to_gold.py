import sys
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions

args = getResolvedOptions(sys.argv, ["JOB_NAME", "BUCKET"])
bucket = args["BUCKET"]

sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
job = Job(glue_context)
job.init(args["JOB_NAME"], args)

def read(path):
    return spark.read.parquet(path)

def write(df, path):
    (df.write.mode("overwrite").format("parquet")
       .option("compression", "snappy").save(path))

# -------------------------
# DIM CUSTOMER
# -------------------------
customer = read(f"s3://{bucket}/silver/customer/")
dim_customer = (
    customer.select(
        "customer_id","customer_name","email","phone",
        "city","state","country","created_date","updated_at"
    )
    .withColumn("customer_name", F.trim("customer_name"))
    .withColumn("email", F.lower(F.trim("email")))
)
write(dim_customer, f"s3://{bucket}/gold/dim_customer/")

# -------------------------
# DIM ACCOUNT
# -------------------------
account = read(f"s3://{bucket}/silver/account/")
dim_account = account.select(
    "account_id","customer_id","account_type","account_status",
    "opening_date","balance","currency","updated_at"
)
write(dim_account, f"s3://{bucket}/gold/dim_account/")

# -------------------------
# DIM PRODUCT
# -------------------------
product = read(f"s3://{bucket}/silver/product/")
dim_product = product.select(
    "product_id","product_name","product_type","risk_category",
    "interest_rate","status","created_date"
)
write(dim_product, f"s3://{bucket}/gold/dim_product/")

# -------------------------
# DIM PORTFOLIO
# -------------------------
portfolio = read(f"s3://{bucket}/silver/portfolio/")
dim_portfolio = portfolio.select(
    "portfolio_id","customer_id","account_id","portfolio_name",
    "portfolio_type","total_value","currency","valuation_date","updated_at"
)
write(dim_portfolio, f"s3://{bucket}/gold/dim_portfolio/")

# -------------------------
# FACT TRANSACTION
# -------------------------
transaction = read(f"s3://{bucket}/silver/transaction/")
fact_transaction = (
    transaction.select(
        "transaction_id","customer_id","account_id","product_id",
        "transaction_date","transaction_type","quantity","price",
        "amount","currency","status","updated_at"
    )
    .withColumn("transaction_id", F.trim("transaction_id"))
    .withColumn("customer_id", F.trim("customer_id"))
    .withColumn("account_id", F.trim("account_id"))
    .withColumn("product_id", F.trim("product_id"))
    .withColumn("transaction_type", F.upper(F.trim("transaction_type")))
    .withColumn("currency", F.upper(F.trim("currency")))
    .withColumn("status", F.upper(F.trim("status")))
)
write(fact_transaction, f"s3://{bucket}/gold/fact_transaction/")

# -------------------------
# DIM DATE
# -------------------------
date_bounds = fact_transaction.select(
    F.min("transaction_date").alias("min_date"),
    F.max("transaction_date").alias("max_date")
).collect()[0]

if date_bounds["min_date"] is not None:
    dim_date = (
        spark.sql(
            f"""SELECT explode(sequence(
                to_date('{date_bounds["min_date"]}'),
                to_date('{date_bounds["max_date"]}'),
                interval 1 day
            )) AS date"""
        )
        .withColumn("date_key", F.date_format("date", "yyyyMMdd").cast("int"))
        .withColumn("year", F.year("date"))
        .withColumn("quarter", F.quarter("date"))
        .withColumn("month", F.month("date"))
        .withColumn("month_name", F.date_format("date", "MMMM"))
        .withColumn("day", F.dayofmonth("date"))
        .withColumn("day_of_week", F.dayofweek("date"))
        .withColumn("day_name", F.date_format("date", "EEEE"))
    )
    write(dim_date, f"s3://{bucket}/gold/dim_date/")

job.commit()
