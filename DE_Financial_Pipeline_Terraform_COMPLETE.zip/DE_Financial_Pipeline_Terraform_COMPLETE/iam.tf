data "aws_caller_identity" "current" {}

resource "aws_iam_role" "glue" {
  name = "financial-poc-glue-role"
  assume_role_policy = jsonencode({
    Version="2012-10-17",
    Statement=[{Effect="Allow",Principal={Service="glue.amazonaws.com"},Action="sts:AssumeRole"}]
  })
}

resource "aws_iam_role_policy_attachment" "glue_service" {
  role = aws_iam_role.glue.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}

resource "aws_iam_role_policy" "glue_s3" {
  name = "financial-poc-glue-s3"
  role = aws_iam_role.glue.id
  policy = jsonencode({
    Version="2012-10-17",
    Statement=[{Effect="Allow",Action="s3:*",Resource=[aws_s3_bucket.data.arn,"${aws_s3_bucket.data.arn}/*"]}]
  })
}

resource "aws_iam_role" "stepfunctions" {
  name = "financial-poc-stepfunctions-role"
  assume_role_policy = jsonencode({
    Version="2012-10-17",
    Statement=[{Effect="Allow",Principal={Service="states.amazonaws.com"},Action="sts:AssumeRole"}]
  })
}

resource "aws_iam_role_policy" "stepfunctions_glue" {
  name = "financial-poc-stepfunctions-glue-policy"
  role = aws_iam_role.stepfunctions.id
  policy = jsonencode({
    Version="2012-10-17",
    Statement=[{
      Effect="Allow",
      Action=["glue:StartJobRun","glue:GetJobRun","glue:GetJobRuns","glue:BatchStopJobRun"],
      Resource=[
        "arn:aws:glue:${var.aws_region}:${data.aws_caller_identity.current.account_id}:job/${var.bronze_to_silver_job_name}",
        "arn:aws:glue:${var.aws_region}:${data.aws_caller_identity.current.account_id}:job/${var.silver_to_gold_job_name}"
      ]
    }]
  })
}

resource "aws_iam_role" "lambda" {
  name = "financial-poc-s3-trigger-role"
  assume_role_policy = jsonencode({
    Version="2012-10-17",
    Statement=[{Effect="Allow",Principal={Service="lambda.amazonaws.com"},Action="sts:AssumeRole"}]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_basic" {
  role = aws_iam_role.lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "lambda_sfn" {
  name = "financial-poc-start-stepfunctions"
  role = aws_iam_role.lambda.id
  policy = jsonencode({
    Version="2012-10-17",
    Statement=[{Effect="Allow",Action="states:StartExecution",Resource=aws_sfn_state_machine.pipeline.arn}]
  })
}
