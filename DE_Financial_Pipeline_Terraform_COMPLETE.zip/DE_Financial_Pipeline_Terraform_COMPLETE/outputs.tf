output "bucket_name" { value = aws_s3_bucket.data.bucket }
output "glue_database" { value = aws_glue_catalog_database.financial.name }
output "lambda_function" { value = aws_lambda_function.trigger.function_name }
output "state_machine_arn" { value = aws_sfn_state_machine.pipeline.arn }
output "gold_crawler" { value = aws_glue_crawler.gold.name }
