resource "aws_glue_catalog_database" "financial" {
  name = var.glue_database_name
}

resource "aws_s3_object" "bronze_script" {
  bucket = aws_s3_bucket.data.id
  key = "scripts/glue_bronze_to_silver.py"
  source = "${path.module}/glue/glue_bronze_to_silver.py"
  etag = filemd5("${path.module}/glue/glue_bronze_to_silver.py")
}

resource "aws_s3_object" "gold_script" {
  bucket = aws_s3_bucket.data.id
  key = "scripts/glue_silver_to_gold.py"
  source = "${path.module}/glue/glue_silver_to_gold.py"
  etag = filemd5("${path.module}/glue/glue_silver_to_gold.py")
}

resource "aws_glue_job" "bronze_to_silver" {
  name = var.bronze_to_silver_job_name
  role_arn = aws_iam_role.glue.arn
  glue_version = "4.0"
  worker_type = "G.1X"
  number_of_workers = 2

  command {
    name = "glueetl"
    script_location = "s3://${var.bucket_name}/scripts/glue_bronze_to_silver.py"
    python_version = "3"
  }

  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" = "true"
  }

  depends_on = [aws_s3_object.bronze_script]
}

resource "aws_glue_job" "silver_to_gold" {
  name = var.silver_to_gold_job_name
  role_arn = aws_iam_role.glue.arn
  glue_version = "4.0"
  worker_type = "G.1X"
  number_of_workers = 2

  command {
    name = "glueetl"
    script_location = "s3://${var.bucket_name}/scripts/glue_silver_to_gold.py"
    python_version = "3"
  }

  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" = "true"
  }

  depends_on = [aws_s3_object.gold_script]
}

resource "aws_glue_crawler" "gold" {
  name = var.crawler_name
  role = aws_iam_role.glue.arn
  database_name = aws_glue_catalog_database.financial.name

  s3_target { path = "s3://${var.bucket_name}/gold/" }

  schema_change_policy {
    update_behavior = "UPDATE_IN_DATABASE"
    delete_behavior = "DEPRECATE_IN_DATABASE"
  }
}
