# DE Financial Pipeline - Complete Terraform POC

This package captures the working AWS POC as rebuildable infrastructure.

## Flow
S3 landing -> Lambda -> Step Functions -> Glue Bronze/Silver -> Glue Silver/Gold -> Glue Catalog -> Athena

## Gold model
- dim_customer
- dim_account
- dim_product
- dim_portfolio
- dim_date
- fact_transaction

## Build
1. Put the included/validated Glue scripts in `glue/`.
2. Review `terraform.tfvars.example`.
3. Copy it to `terraform.tfvars` and adjust values if needed.
4. Run:
   terraform init
   terraform fmt
   terraform validate
   terraform plan
   terraform apply

## Destroy
After backing up any data you need:
    terraform destroy

Terraform manages infrastructure and code deployment. It does not manage your CSV/Parquet business data as resources.

## Existing manually-created AWS resources
If your current AWS environment was created by CLI rather than Terraform, do NOT run terraform destroy expecting Terraform to remove those resources. Either import them or perform a clean POC teardown and rebuild from this package.

## QuickSight
QuickSight is intentionally not provisioned here because the account/subscription state is separate from the core pipeline. Add it only after deciding on the QuickSight edition and permissions.
