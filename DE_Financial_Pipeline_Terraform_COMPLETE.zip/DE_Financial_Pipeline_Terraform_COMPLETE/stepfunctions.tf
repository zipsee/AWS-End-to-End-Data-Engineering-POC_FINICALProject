resource "aws_sfn_state_machine" "pipeline" {
  name = var.state_machine_name
  role_arn = aws_iam_role.stepfunctions.arn

  definition = jsonencode({
    Comment = "Financial POC - End-to-End Data Pipeline"
    StartAt = "BronzeToSilver"
    States = {
      BronzeToSilver = {
        Type = "Task"
        Resource = "arn:aws:states:::glue:startJobRun.sync"
        Parameters = {
          JobName = var.bronze_to_silver_job_name
          Arguments = { "--BUCKET.$" = "$.bucket" }
        }
        Next = "SilverToGold"
        Catch = [{ ErrorEquals = ["States.ALL"], Next = "PipelineFailed" }]
      }
      SilverToGold = {
        Type = "Task"
        Resource = "arn:aws:states:::glue:startJobRun.sync"
        Parameters = {
          JobName = var.silver_to_gold_job_name
          Arguments = { "--BUCKET.$" = "$.bucket" }
        }
        Next = "PipelineSucceeded"
        Catch = [{ ErrorEquals = ["States.ALL"], Next = "PipelineFailed" }]
      }
      PipelineSucceeded = { Type = "Succeed" }
      PipelineFailed = { Type = "Fail", Cause = "Financial data pipeline failed" }
    }
  })
}
