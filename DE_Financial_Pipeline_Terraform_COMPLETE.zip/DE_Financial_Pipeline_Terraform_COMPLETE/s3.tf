resource "aws_s3_bucket" "data" {
  bucket = var.bucket_name
}

resource "aws_s3_bucket_versioning" "data" {
  bucket = aws_s3_bucket.data.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_object" "folders" {
  for_each = toset([
    "landing/account/","landing/customer/","landing/portfolio/","landing/product/","landing/transaction/",
    "bronze/account/","bronze/customer/","bronze/portfolio/","bronze/product/","bronze/transaction/",
    "silver/account/","silver/customer/","silver/portfolio/","silver/product/","silver/transaction/",
    "gold/dim_customer/","gold/dim_account/","gold/dim_product/","gold/dim_portfolio/","gold/dim_date/",
    "gold/fact_transaction/","gold/daily_portfolio_summary/",
    "quarantine/business_rule/","quarantine/datatype/","quarantine/duplicate/","quarantine/null/","quarantine/schema/",
    "rejected/customer/","archive/","audit/data_quality/","audit/pipeline_runs/","scripts/","athena-results/"
  ])
  bucket = aws_s3_bucket.data.id
  key = each.value
  content = ""
}
