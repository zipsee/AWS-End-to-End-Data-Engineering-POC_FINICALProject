variable "aws_region" { type = string default = "ap-south-1" }
variable "bucket_name" { type = string default = "financial-data-engineering-poc-bhargav-2026" }
variable "glue_database_name" { type = string default = "financial_poc" }
variable "bronze_to_silver_job_name" { type = string default = "financial-poc-bronze-to-silver" }
variable "silver_to_gold_job_name" { type = string default = "financial-poc-silver-to-gold" }
variable "crawler_name" { type = string default = "financial-poc-gold-crawler" }
variable "lambda_name" { type = string default = "financial-poc-s3-stepfunctions-trigger" }
variable "state_machine_name" { type = string default = "financial-poc-daily-pipeline" }
