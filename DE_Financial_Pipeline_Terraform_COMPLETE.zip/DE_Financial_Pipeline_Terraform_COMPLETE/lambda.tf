data "archive_file" "lambda_zip" {
  type = "zip"
  source_file = "${path.module}/lambda/s3_stepfunctions_trigger.py"
  output_path = "${path.module}/s3_stepfunctions_trigger.zip"
}

resource "aws_lambda_function" "trigger" {
  function_name = var.lambda_name
  role = aws_iam_role.lambda.arn
  runtime = "python3.12"
  handler = "s3_stepfunctions_trigger.lambda_handler"
  filename = data.archive_file.lambda_zip.output_path
  source_code_hash = data.archive_file.lambda_zip.output_base64sha256
  timeout = 30

  environment {
    variables = { STATE_MACHINE_ARN = aws_sfn_state_machine.pipeline.arn }
  }
}

resource "aws_lambda_permission" "s3" {
  statement_id = "s3-invoke-permission"
  action = "lambda:InvokeFunction"
  function_name = aws_lambda_function.trigger.function_name
  principal = "s3.amazonaws.com"
  source_arn = aws_s3_bucket.data.arn
  source_account = data.aws_caller_identity.current.account_id
}

resource "aws_s3_bucket_notification" "trigger" {
  bucket = aws_s3_bucket.data.id

  lambda_function {
    lambda_function_arn = aws_lambda_function.trigger.arn
    events = ["s3:ObjectCreated:*"]
    filter_prefix = "landing/"
  }

  depends_on = [aws_lambda_permission.s3]
}
