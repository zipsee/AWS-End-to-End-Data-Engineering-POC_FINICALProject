resource "aws_athena_workgroup" "financial" {
  name = "financial-poc"
  configuration {
    enforce_workgroup_configuration = true
    result_configuration {
      output_location = "s3://${var.bucket_name}/athena-results/"
    }
  }
}
